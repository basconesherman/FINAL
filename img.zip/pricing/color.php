<?php
	$id = $_COOKIE["user"];
		
		$paperType = $_COOKIE['paper_opt'];
		$plyFront = $_COOKIE['ply_f'];
		$pfront = $_COOKIE['paper_f'];
		$pback = $_COOKIE['paper_b'];
		$total = $_COOKIE['price_total'];
		$ply1 = $_COOKIE['ply_f'];
		$ply2 = $_COOKIE['ply_b'];
		$type = $_COOKIE['paper_opt'];
		$quant = $_COOKIE['quantity'];
	if(($paperType == "duplex-stock") || ($plyFront == "2")){
		echo "
			<script src='../js/jquery-1.7.2.min.js'></script>
			<script>
			$(document).ready(function(){
					$( '#duplex-color-tab-hidden' ).addClass( 'activated', -1000);
					$( '#duplex-color-tab-hidden' ).removeClass( 'deactivated')
					
					$( '#image' ).addClass( 'deactivated', -1000);
					$( '#image' ).removeClass( 'activated');
			});
			</script>
		";
	}
	else{
		echo "
			<script src='../js/jquery-1.7.2.min.js'></script>
			<script>
			$(document).ready(function(){
					$( '#duplex-color-tab-hidden' ).addClass( 'deactivated', -1000);
					$( '#duplex-color-tab-hidden' ).removeClass( 'activated')
					
					$( '#image' ).addClass( 'activated', -1000);
					$( '#image' ).removeClass( 'deactivated');
			});
			</script>
		";
	}
?>
<html>
	<head>
		<title>Pricing & Ordering | Letterpress Business Cards</title>
		<?php include 'library/imports1.php';?>
		<?php include '../js/color_calcu.php';?>
		<link type="text/css" rel="stylesheet" href="css/pricing.css"/>
		<link type="text/css" rel="stylesheet" href="css/paper.css"/>
		<link type="text/css" rel="stylesheet" href="css/2cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/3cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/6cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/7cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/8cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/9cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/10cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/11cols.css"/>
		<link type="text/css" rel="stylesheet" href="css/12cols.css"/>
	</head>
	<body onLoad="remember()">
	
		<div class="container">
			<?php include '../lib/header-pricing.php';?>
			<?php include '../lib/nav-price.php';?>
			<div class="content-grid">
				<div class="title">
					<p id="title">PRICING <span> & </span> ORDERING</p>
					<p id="sub-title">LET'S GET YOUR DESIGN ON</p>
				</div>
				<div id="tabs">
					<ul>
						<a href="index.php"><li><img src="images/pricing-1.png"></li></a>
						<a href="size.php"><li><img src="images/pricing-2.png"></li></a>
						<a href="quantity.php"><li><img src="images/pricing-3.png"></li></a>
						<a href="color.php"><li><img src="images/pricing-4-active.png"></li></a>
						<a href="extras.php"><li><img src="images/pricing-5.png"></li></a>
						<a href="upload.php"><li><img src="images/pricing-6.png"></li></a>
						<li id="total"><center><p id="totalValue">$<?php echo $total;?>.00</p></center></li>
					</ul>
				</div>
			</div>
			<div id="colors-box">
				<form action="color-process.php" method="post">
					<input id="paperTotal" name="paperTotal" style="display:;">
					<div class="content-grid">
						<br/><br/>
						<div id="color-options">
							<input type="radio" id="front" class="options" name="paper" value="all" checked>
							<label class="paper" for="front">
								<div>
									<h2 class="text-option">FRONT SIDE</h2>
								</div>
							</label>
							
							<input type="radio" id="back" class="options" name="paper" value="all">
							<label class="paper" for="back" style="float:right;">
								<div>
									<h2 class="text-option">BACK SIDE</h2>
								</div>
							</label>
						</div>
						<div id="single-color-tab">	
							<?php
								echo "<script>$(document).ready(function(){";
									if($pfront == "Crest 1 ply pearl" || $pfront == "Crest 2 ply pearl"){
										echo "$( '#paper1-color' ).addClass( 'crest', -1000);";
									}
									else if($pfront == "Lettra 1 ply pearl" || $pfront == "Lettra 2 ply pearl"){
										echo "$( '#paper1-color' ).addClass( 'pearl', -1000);";
									}
									else if($pfront == "CP 1 ply dark grey"){
										echo "$( '#paper1-color' ).addClass( 'd-gray', -1000);";
									}
									else if($pfront == "CP 1 ply real grey"){
										echo "$( '#paper1-color' ).addClass( 'r-gray', -1000);";
									}
									else if($pfront == "Arturo 1 ply stone"){
										echo "$( '#paper1-color' ).addClass( 'stone', -1000);";
									}
									else if($pfront == "Kraft 1 ply"){
										echo "$( '#paper1-color' ).addClass( 'kraft', -1000);";
									}
									else if($pfront == "CP 1 ply scarlet"){
										echo "$( '#paper1-color' ).addClass( 'scarlet', -1000);";
									}
									else if($pfront == "Arturo 1 ply rosa"){
										echo "$( '#paper1-color' ).addClass( 'rosa', -1000);";
									}
									else if($pfront == "CP 1 ply navy"){
										echo "$( '#paper1-color' ).addClass( 'navy', -1000);";
									}
									else if($pfront == "CP 1 ply mint"){
										echo "$( '#paper1-color' ).addClass( 'mint', -1000);";
									}
								echo "});</script>"
							?>
							
							<h2 class="color-paper" style="margin-left:20px;">
								PAPER SELECTED
								<br/>IN STEP NO.1
								<img class="arrow size-arrow" src="images/arrow.png" />
								
								<input type="text" style="display:none;" name="radios">
								<label for="radio1" id="paper-title1">
									<div id="paper1-color" class="items items2" >
										<h2 class="item-text-box"><?php echo $pfront;?></h2>
									</div>
								</label>
							</h2>
							<br/>
							
							<div class="title">
								<p id="title" style="text-align:left;font-size:28pt;margin-left:20px;">NUMBER OF INK COLORS:</p>
							</div>
							
							<div id="single-colors" style="margin-top:-50px;margin-left:50px;display:block:position:absolute;" class="colorNum">
									
									<div id="select1" class="col span_1_of_10">
										<div  class="col span_1_of_2">
											<div id="radioSelect1" class="radioBtn btns1">
												<div id="radio1" class="radioBtnInside activated" data-key1="1">
													
												</div>
											</div>
										</div>
										<div  class="col span_1_of_2">
											<h2 class="color-text right">1</h2>
										</div>
									</div>
									<div  class="col span_1_of_10">
										
									</div>
									<div  class="col span_1_of_10">
										<div  class="col span_1_of_2">
											<div id="radioSelect2" class="radioBtn btns1">
												<div id="radio2" class="radioBtnInside deactivated" data-key2="2">
													
												</div>
											</div>
										</div>
										<div  class="col span_1_of_2">
											<h2 class="color-text right">2</h2>
										</div>
									</div>
									<div  class="col span_1_of_10">
										
									</div>
									<div  class="col span_1_of_10">
										<div  class="col span_1_of_2">
											<div id="radioSelect3" class="radioBtn btns1">
												<div id="radio3" class="radioBtnInside deactivated" data-key3="3">
													
												</div>
											</div>
										</div>
										<div class="col span_1_of_2">
											<h2 class="color-text right">3</h2>
										</div>
									</div>
							</div>
							<input id="frontNum" type="text" name="frontNum" value="<?php echo $_COOKIE['front_num'];?>" style="display:none;"/>
							
							<!-- TABS FOR COLOR NUMBER -->
							<!-- FOR 1 COLOR -->
							<div id="colors1" class="section group activated">
								<div class="section group">
									<img class="arrow" src="images/arrow.png" /><p class="color-desc">COLOR NO.1</p>
									<div class="color-grid">
										<div class="col span_4_of_12">
											<div  class="col span_1_of_5">
												<div id="typeSelect1" class="radioBtn">
													<div id="type1" class="radioBtnInside activated">
														
													</div>
												</div>
											</div>
											<div  class="col span_4_of_5">
												<h2 class="color-text2 left">Letterpress</h2>
											</div>
										</div>
										<div class="col span_4_of_12">
											<div  class="col span_1_of_5">
												<div id="typeSelect2" class="radioBtn">
													<div id="type2" class="radioBtnInside deactivated">
														
													</div>
												</div>
											</div>
											<div  class="col span_4_of_5">
												<h2 class="color-text2 left">Foil</h2>
											</div>
										</div>
										
										<div id="letterpress1" class="activated">
											<h2 style="margin:50px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Pantone(PMS)Number:</h2>
											<input class="letterpress" type="text" name="letterpress-color1" value="" />
										</div>
										
										<div id="foil1" class="section group deactivated">
											<h2 style="margin:-12px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Foil Color:</h2>
											<select class="foil" name="foil-color1">
												<option value="None">SELECT ONE</option>
												<option value="gold">GOLD</option>
												<option value="silver">SILVER</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							
							<!-- FOR 2 COLOR -->
							<div id="colors2" class="section group color-content deactivated">
								<div class="section group">
									<div class="section group"><div id="line2"></div></div>
									<img class="arrow" src="images/arrow.png" /><p class="color-desc">COLOR NO.2</p>
									<div class="color-grid">
										<div class="col span_4_of_12">
											<div  class="col span_1_of_5">
												<div id="typeSelect3" class="radioBtn">
													<div id="type3" class="radioBtnInside activated">
														
													</div>
												</div>
											</div>
											<div  class="col span_4_of_5">
												<h2 class="color-text2 left">Letterpress</h2>
											</div>
										</div>
										<div class="col span_4_of_12">
											<div  class="col span_1_of_5">
												<div id="typeSelect4" class="radioBtn">
													<div id="type4" class="radioBtnInside deactivated">
														
													</div>
												</div>
											</div>
											<div  class="col span_4_of_5">
												<h2 class="color-text2 left">Foil</h2>
											</div>
										</div>
										
										<div id="letterpress2" class="activated">
											<h2 style="margin:50px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Pantone(PMS)Number:</h2>
											<input class="letterpress" type="text" name="letterpress-color2" value="" />
										</div>
										
										<div id="foil2" class="section group deactivated">
											<h2 style="margin:-12px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Foil Color:</h2>
											<select class="foil" name="foil-color2">
												<option value="None">SELECT ONE</option>
												<option value="gold">GOLD</option>
												<option value="silver">SILVER</option>
											</select>
										</div>
									</div>
								</div>
							</div>
							
							<!-- FOR 3 COLOR -->
							<div id="colors3" class="section group color-content deactivated">
								<div class="section group">
									<div class="section group"><div id="line2"></div></div>
									<img class="arrow" src="images/arrow.png" /><p class="color-desc">COLOR NO.3</p>
									<div class="color-grid">
										<div class="col span_4_of_12">
											<div  class="col span_1_of_5">
												<div id="typeSelect5" class="radioBtn">
													<div id="type5" class="radioBtnInside activated">
														
													</div>
												</div>
											</div>
											<div  class="col span_4_of_5">
												<h2 class="color-text2 left">Letterpress</h2>
											</div>
										</div>
										<div class="col span_4_of_12">
											<div  class="col span_1_of_5">
												<div id="typeSelect6" class="radioBtn">
													<div id="type6" class="radioBtnInside deactivated">
														
													</div>
												</div>
											</div>
											<div  class="col span_4_of_5">
												<h2 class="color-text2 left">Foil</h2>
											</div>
										</div>
										
										<div id="letterpress3" class="activated">
											<h2 style="margin:50px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Pantone(PMS)Number:</h2>
											<input class="letterpress" type="text" name="letterpress-color3" value="" />
										</div>
										
										<div id="foil3" class="section group deactivated">
											<h2 style="margin:-12px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Foil Color:</h2>
											<select class="foil" name="foil-color3">
												<option value="None">SELECT ONE</option>
												<option value="gold">GOLD</option>
												<option value="silver">SILVER</option>
											</select>
										</div>
									</div>
								</div>
							</div>
						</div>
						
						<script>
							function remember(){
								var plyCheck1 = <?php echo $_COOKIE['ply_f'];?>;
								var plyCheck2 = <?php echo $_COOKIE['ply_b'];?>;
								var ptype = "<?php echo $_COOKIE['paper_opt'];?>";
								
								if( (plyCheck1 > 1) || (plyCheck2 > 1) || (ptype == "duplex-stock")){
									$( "#duplex-color-tab" ).addClass( "activated", -1000);
									$( "#duplex-color-tab" ).removeClass( "deactivated");
								}
								else{
									$( "#duplex-color-tab" ).addClass( "deactivated", -1000);
								}
								
								
								<!-- Remember value after form submission | front color number-->
								for(var j = 1; j <= 3; j++){
									var datakey = $("#radio"+j).data("key"+j);
									if ( datakey == <?php echo $_COOKIE['front_num'];?> ) {
										$( "#radio"+j ).addClass( "activated", -1000);
										$( "#radio"+j ).removeClass( "deactivated");
										if(datakey == 1){color1();}
										if(datakey == 2){color2();}
										if(datakey == 3){color3();}
									}
									else{
										$( "#radio"+j ).removeClass( "activated");
										$( "#radio"+j ).addClass( "deactivated", -1000);
									}
								}
								
								<!-- Remember value after form submission | back color number-->
								for(var h = 5; h <= 7; h++){
									var datakey = $("#radio"+h).data("key"+h);
									if ( (datakey) == <?php echo $_COOKIE['back_num'];?> ) {
										$( "#radio"+h ).addClass( "activated", -1000);
										$( "#radio"+h ).removeClass( "deactivated");
										if((datakey) == 1){color4();}
										if((datakey) == 2){color5();}
										if((datakey) == 3){color6();}
									}
									else{
										$( "#radio"+h ).removeClass( "activated");
										$( "#radio"+h ).addClass( "deactivated", -1000);
									}
								}
							}
							<?php include "colors.php";?>
						</script>
						
						
						<div id="duplex-color-tab" class="deactivated">
							<center><img style="margin-top:100px;" id="image" src="images/color-not-available.png" /></center>
							
							<div id="duplex-color-tab-hidden" class="deactivated">
								<?php
									echo "<script>$(document).ready(function(){";
										if($pback == "Crest 1 ply pearl" || $pback == "Crest 2 ply pearl"){
											echo "$( '#paper2-color' ).addClass( 'crest', -1000);";
										}
										else if($pback == "Lettra 1 ply pearl" || $pback == "Lettra 2 ply pearl"){
											echo "$( '#paper2-color' ).addClass( 'pearl', -1000);";
										}
										else if($pback == "CP 1 ply dark grey"){
											echo "$( '#paper2-color' ).addClass( 'd-gray', -1000);";
										}
										else if($pback == "CP 1 ply real grey"){
											echo "$( '#paper2-color' ).addClass( 'r-gray', -1000);";
										}
										else if($pback == "Arturo 1 ply stone"){
											echo "$( '#paper2-color' ).addClass( 'stone', -1000);";
										}
										else if($pback == "Kraft 1 ply"){
											echo "$( '#paper2-color' ).addClass( 'kraft', -1000);";
										}
										else if($pback == "CP 1 ply scarlet"){
											echo "$( '#paper2-color' ).addClass( 'scarlet', -1000);";
										}
										else if($pback == "Arturo 1 ply rosa"){
											echo "$( '#paper2-color' ).addClass( 'rosa', -1000);";
										}
										else if($pback == "CP 1 ply navy"){
											echo "$( '#paper2-color' ).addClass( 'navy', -1000);";
										}
										else if($pback == "CP 1 ply mint"){
											echo "$( '#paper2-color' ).addClass( 'mint', -1000);";
										}
										else if($pback == '0'){$pback = "None";}
									echo "});</script>"
								?>
							
								<h2 class="color-paper">
									PAPER SELECTED
									<br/>IN STEP NO.1
									<img class="arrow size-arrow" src="images/arrow.png" />
									
									<input type="text" style="display:none;" name="radios">
									<label for="radio1"  id="paper-title1">
										<div id="paper2-color" class="items items2" >
											<h2 class="item-text-box"><?php echo $pback;?></h2>
										</div>
									</label>
								</h2>
								<br/>
								<div class="title">
									<p id="title" style="text-align:left;font-size:28pt;">NUMBER OF INK COLORS:</p>
								</div>
								
								<div id="duplex-colors" style="margin-top:-50px;margin-left:30px;" class="colorNum">
									<div>
										
										<div  class="col span_1_of_10">
											<div  class="col span_1_of_2">
												<div id="radioSelect5" class="radioBtn">
													<div id="radio5" class="radioBtnInside activated" data-key5="1">
														
													</div>
												</div>
											</div>
											<div  class="col span_1_of_2">
												<h2 class="color-text right">1</h2>
											</div>
										</div>
										<div  class="col span_1_of_10">
											
										</div>
										<div  class="col span_1_of_10">
											<div  class="col span_1_of_2">
												<div id="radioSelect6" class="radioBtn">
													<div id="radio6" class="radioBtnInside deactivated" data-key6="2">
														
													</div>
												</div>
											</div>
											<div  class="col span_1_of_2">
												<h2 class="color-text right">2</h2>
											</div>
										</div>
										<div  class="col span_1_of_10">
											
										</div>
										<div  class="col span_1_of_10">
											<div  class="col span_1_of_2">
												<div id="radioSelect7" class="radioBtn">
													<div id="radio7" class="radioBtnInside deactivated" data-key7="3">
														
													</div>
												</div>
											</div>
											<div class="col span_1_of_2">
												<h2 class="color-text right">3</h2>
											</div>
										</div>
									</div>
								</div>
								<input id="backNum" type="text" name="backNum" value="<?php echo $_COOKIE['back_num'];?>" style="display:none;"/>
								
								<!-- TABS FOR COLOR NUMBER -->
								<!-- FOR 1 COLOR -->
								<div id="colors4" class="section group activated">
									<div class="section group">
										<img class="arrow" src="images/arrow.png" /><p class="color-desc">COLOR NO.1</p>
										<div class="color-grid">
											<div class="col span_4_of_12">
												<div  class="col span_1_of_5">
													<div id="typeSelect7" class="radioBtn">
														<div id="type7" class="radioBtnInside activated">
															
														</div>
													</div>
												</div>
												<div  class="col span_4_of_5">
													<h2 class="color-text2 left">Letterpress</h2>
												</div>
											</div>
											<div class="col span_4_of_12">
												<div  class="col span_1_of_5">
													<div id="typeSelect8" class="radioBtn">
														<div id="type8" class="radioBtnInside deactivated">
															
														</div>
													</div>
												</div>
												<div  class="col span_4_of_5">
													<h2 class="color-text2 left">Foil</h2>
												</div>
											</div>
											
											<div id="letterpress4" class="activated">
												<h2 style="margin:50px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Pantone(PMS)Number:</h2>
												<input class="letterpresses" type="text" name="letterpress-color4" />
											</div>
											
											<div id="foil4" class="section group deactivated">
												<h2 style="margin:-12px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Foil Color:</h2>
												<select class="foil" name="foil-color4">
													<option value="None">SELECT ONE</option>
													<option value="gold">GOLD</option>
													<option value="silver">SILVER</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								
								<!-- FOR 2 COLOR -->
								<div id="colors5" class="section group color-content deactivated">
									<div class="section group">
										<div class="section group"><div id="line2"></div></div>
										<img class="arrow" src="images/arrow.png" /><p class="color-desc">COLOR NO.2</p>
										<div class="color-grid">
											<div class="col span_4_of_12">
												<div  class="col span_1_of_5">
													<div id="typeSelect9" class="radioBtn">
														<div id="type9" class="radioBtnInside activated">
															
														</div>
													</div>
												</div>
												<div  class="col span_4_of_5">
													<h2 class="color-text2 left">Letterpress</h2>
												</div>
											</div>
											<div class="col span_4_of_12">
												<div  class="col span_1_of_5">
													<div id="typeSelect10" class="radioBtn">
														<div id="type10" class="radioBtnInside deactivated">
															
														</div>
													</div>
												</div>
												<div  class="col span_4_of_5">
													<h2 class="color-text2 left">Foil</h2>
												</div>
											</div>
											
											<div id="letterpress5" class="activated">
												<h2 style="margin:50px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Pantone(PMS)Number:</h2>
												<input class="letterpresses" type="text" name="letterpress-color5" />
											</div>
											
											<div id="foil5" class="section group deactivated">
												<h2 style="margin:-12px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Foil Color:</h2>
												<select class="foil" name="foil-color5">
													<option value="None">SELECT ONE</option>
													<option value="gold">GOLD</option>
													<option value="silver">SILVER</option>
												</select>
											</div>
										</div>
									</div>
								</div>
								
								<!-- FOR 3 COLOR -->
								<div id="colors6" class="section group color-content deactivated">
									<div class="section group">
										<div class="section group"><div id="line2"></div></div>
										<img class="arrow" src="images/arrow.png" /><p class="color-desc">COLOR NO.3</p>
										<div class="color-grid">
											<div class="col span_4_of_12">
												<div  class="col span_1_of_5">
													<div id="typeSelect11" class="radioBtn">
														<div id="type11" class="radioBtnInside activated">
															
														</div>
													</div>
												</div>
												<div  class="col span_4_of_5">
													<h2 class="color-text2 left">Letterpress</h2>
												</div>
											</div>
											<div class="col span_4_of_12">
												<div  class="col span_1_of_5">
													<div id="typeSelect12" class="radioBtn">
														<div id="type12" class="radioBtnInside deactivated">
															
														</div>
													</div>
												</div>
												<div  class="col span_4_of_5">
													<h2 class="color-text2 left">Foil</h2>
												</div>
											</div>
											
											<div id="letterpress6" class="activated">
												<h2 style="margin:50px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Pantone(PMS)Number:</h2>
												<input class="letterpresses" type="text" name="letterpress-color6" />
											</div>
											
											<div id="foil6" class="section group deactivated">
												<h2 style="margin:-12px 0 0 -25px;position:absolute;font-size:16pt;" class="color-text2 left">Foil Color:</h2>
												<select class="foil" name="foil-color6">
													<option value="None">SELECT ONE</option>
													<option value="gold">GOLD</option>
													<option value="silver">SILVER</option>
												</select>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<br/><br/>
				
			</div>
			<div class="section group" style="display:block;">
				<br/><br/>
				<div class="content-grid">
				<a type="button" style="display:absolute;margin-top:20px;cursor:pointer;" href="quantity.php"><img src="images/prev-btn.png"></a>
				<input id="size-submit" type="submit" value="" />
				</div>
			</div>
				</form>
			<img style="margin-top:-90px;margin-left:190px;" class="quote" src="images/color-quote.png" width="606px" height="81px">
			<?php include '../lib/footer.php';?>
		</div>
	</body>
</html>