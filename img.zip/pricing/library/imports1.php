<link type="text/css" rel="stylesheet" href="../css/lbc.css"/>
<link type="text/css" rel="stylesheet" href="../css/header.css"/>
<link type="text/css" rel="stylesheet" href="css/navbar.css"/>

<!-- All JavaScript at the bottom, except for Modernizr which enables HTML5 elements and feature detects -->
<script src="../js/jquery-1.7.2.min.js"></script>
<link rel="stylesheet" href="//code.jquery.com/ui/1.10.4/themes/smoothness/jquery-ui.css">
<script src="../js/effects2.js"></script>
<script src="../js/calculator2.js"></script>