<div id="navigation">
	<div class="grid">
		<ul>
			<li><a href="#">CARD ANATOMY</a></li>
			<li><a href="../process.php">PROCESS</a></li>
			<li><a id="special" href="index.php">Pricing & Ordering</a></li>
			<li><a href="../team.php">TEAM</a></li>
			<li><a href="#">BLOG</a></li>
			<li><a href="../contact.php">CONTACT</a></li>
		</ul>
	</div>
</div>