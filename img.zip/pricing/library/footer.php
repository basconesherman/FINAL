<div id="footer" class="section group">
	<div class="grid">
		<p>
			&copy the aerialist press 2014<br/>1514 PARK AVENUE,EMERYVILLE, CALIFORNIA 94608
		</p>
	</div>
</div>