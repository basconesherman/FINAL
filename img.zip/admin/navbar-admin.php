<div id="navbar-admin">
	<ul>
		<li><a href="user.php">Users</a></li>
		<li><a href="orders.php">Orders</a></li>
		<li><a href="#">Price Changer</a></li>
		<li><a href="account.php">Account</a></li>
		<li><a href="upload.php">Upload</a></li>
		<li><a href="../index.php">Logout</a></li>
	</ul>
</div>