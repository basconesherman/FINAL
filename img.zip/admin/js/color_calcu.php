<script>
$(document).ready(function() {	
	var paper = $("#stock").val();
	var quantity = 100;
	var color1 = 0;
	var color2 = 0;
	var total = 0;
	
	alert(paper)
});
</script>